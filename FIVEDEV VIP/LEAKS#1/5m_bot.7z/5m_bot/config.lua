Config                        = {}
Config.Locale 				  = 'fr'
Config.green 				  = 56108
Config.grey 				  = 8421504
Config.red 					  = 16711680
Config.orange 				  = 16744192
Config.blue 				  = 2061822
Config.purple 				  = 11750815
Config.webhook                = "https://discordapp.com/api/webhooks/694307319172956251/azq55EKJrer5IZdwbfLBU4p58EFnEDlhKswhPYtFoA79u8nfZ41Vhi0VBSkBUTLZw8Hu"

Config.LogKills = true -- Log when a player kill an other player.
Config.LogEnterPoliceVehicle = false -- Log when an player enter in a police vehicle.
Config.LogEnterBlackListedVehicle = false -- Log when a player enter in a blacklisted vehicle.
Config.LogPedJacking = true -- Log when a player is jacking a car
Config.LogChatServer = true -- Log when a player is talking in the chat , /command works too.
Config.LogLoginServer = true -- Log when a player is connecting/disconnecting to the server.
Config.LogItemTransfer = true -- Log when a player is giving an item.
Config.LogWeaponTransfer = true -- Log when a player is giving a weapon.
Config.LogMoneyTransfer = true -- Log when a player is giving money
Config.LogMoneyBankTransfert = true -- Log when a player is giving money from bankaccount
Config.LogMoneyBankDeposite = true
Config.LogMoneyBankWithdraw = true



blacklistedModels = {

}
